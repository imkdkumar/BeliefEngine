import pytest

pytest.main()
